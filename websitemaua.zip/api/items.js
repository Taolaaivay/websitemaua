// api/items.js
import { getItems } from "./storage.js";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  if (req.method === "OPTIONS") return res.status(200).end();

  try {
    const items = await getItems();
    return res.status(200).json({ success: true, items });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
}
