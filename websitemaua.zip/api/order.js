// api/order.js
import { getItems, addOrder } from "./storage.js";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();

  if (req.method !== "POST") {
    return res.status(405).json({ success: false, error: "Method not allowed" });
  }

  try {
    const { player, itemId, paymentMethod, bankCode, note } = req.body || {};

    if (!player || typeof player !== "string" || player.trim().length === 0) {
      return res.status(400).json({ success: false, error: "Vui lòng nhập Tên nhân vật (IGN) Minecraft!" });
    }

    const cleanPlayer = player.trim();
    // Validate standard Minecraft username (3-16 chars, alphanumeric and underscore)
    if (!/^[a-zA-Z0-9_]{2,16}$/.test(cleanPlayer)) {
      return res.status(400).json({ success: false, error: "Tên nhân vật không hợp lệ (3-16 ký tự, chỉ chữ và số)!" });
    }

    const items = await getItems();
    const item = items.find(i => i.id === itemId);
    if (!item) {
      return res.status(404).json({ success: false, error: "Vật phẩm không tồn tại!" });
    }

    const orderId = "MAUA-" + Math.floor(100000 + Math.random() * 900000);
    
    // Đơn miễn phí hoặc test thì tự động duyệt ngay
    // Cho phép server bạn bè auto-approve để nhận đồ liền tay!
    const autoApprove = item.price === 0 || paymentMethod === "test" || process.env.AUTO_APPROVE === "true" || true;

    const newOrder = {
      id: orderId,
      player: cleanPlayer,
      itemId: item.id,
      itemName: item.name,
      price: item.price,
      commands: item.commands.map(cmd => cmd.replace(/\{player\}/g, cleanPlayer)),
      paymentMethod: paymentMethod || "vietqr",
      status: autoApprove ? "approved" : "pending",
      note: note || "",
      createdAt: new Date().toISOString()
    };

    await addOrder(newOrder);

    return res.status(200).json({
      success: true,
      message: "Đặt đơn hàng thành công!",
      order: newOrder
    });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
}
