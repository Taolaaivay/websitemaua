// api/complete.js
// Endpoint de Plugin Minecraft bao ve rang da phat do thanh cong
import { markOrderCompleted } from "./storage.js";

const DEFAULT_SECRET = "maua_minecraft_key_2026";

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
  if (req.method === "OPTIONS") return res.status(200).end();

  const secret = req.query.secret || (req.body && req.body.secret) || req.headers["x-plugin-secret"];
  const orderId = req.query.orderId || (req.body && req.body.orderId);

  const expectedSecret = process.env.PLUGIN_API_KEY || DEFAULT_SECRET;

  if (secret !== expectedSecret) {
    return res.status(401).json({ success: false, error: "Sai ma khoa bi mat (API Secret Key)!" });
  }

  if (!orderId) {
    return res.status(400).json({ success: false, error: "Thieu ma don hang (orderId)!" });
  }

  try {
    const success = await markOrderCompleted(orderId);
    if (success) {
      return res.status(200).json({ success: true, message: `Don hang ${orderId} da hoan tat!` });
    } else {
      return res.status(404).json({ success: false, error: `Khong tim thay don hang ${orderId}` });
    }
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
}
